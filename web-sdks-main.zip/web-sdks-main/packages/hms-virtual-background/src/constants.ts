export const EFFECTS_SDK_ASSETS = 'https://assets.100ms.live/effectsdk/';
