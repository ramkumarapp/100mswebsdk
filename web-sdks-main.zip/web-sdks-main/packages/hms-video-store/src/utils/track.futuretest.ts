// this doesn't really work in nodejs environment, keeping it for future browser testing or till
// we figure out a way to make it work in node
// describe('empty track', () => {
//   it('gives an empty disabled but ready video track', () => {
//     const track = getEmptyVideoTrack();
//     expect(track.readyState).toBe('live');
//     expect(track.enabled).toBe(false);
//     track.stop();
//   });
// });
export {};
