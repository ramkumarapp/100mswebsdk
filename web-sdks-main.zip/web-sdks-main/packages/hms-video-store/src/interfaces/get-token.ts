export interface TokenRequest {
  roomCode: string;
  userId?: string;
}

export interface TokenRequestOptions {
  endpoint?: string;
}
