![Banner](https://github.com/100mslive/web-sdks/blob/06c65259912db6ccd8617f2ecb6fef51429251ec/prebuilt-banner.png)

# 100ms Prebuilt - React Example

### How to run locally?

- Run `yarn build` at the root level of the repo.
- Then, navigate to this folder and run `yarn dev`

### Facing a problem?
Join us on the [100ms Discord](https://discord.com/invite/kGdmszyzq2) to ask questions and get help from the 100ms team.
