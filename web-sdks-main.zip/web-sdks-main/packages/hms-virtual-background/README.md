## installation

**with npm:**

```npm i --save @100mslive/hms-virtual-background```

**with yarn**

```yarn add @100mslive/hms-virtual-background```

## Usage

Refer our [docs](https://www.100ms.live/docs/javascript/v2/plugins/virtual-background#start-and-stop-virtual-background) for usage.