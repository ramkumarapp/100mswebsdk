export { DeviceManager } from './DeviceManager';
