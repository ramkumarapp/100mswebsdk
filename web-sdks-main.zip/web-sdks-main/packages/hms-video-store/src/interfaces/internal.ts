export interface ServerError {
  code: number;
  message?: string;
}
