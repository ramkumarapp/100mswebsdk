export enum HMSTrackType {
  AUDIO = 'audio',
  VIDEO = 'video',
}
