export enum DomainCategory {
  CUSTOM = 'CUSTOM',
  LOCAL = 'LOCAL',
  HMS = 'HMS',
}
