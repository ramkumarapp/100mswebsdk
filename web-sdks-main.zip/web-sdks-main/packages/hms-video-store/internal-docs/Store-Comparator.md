# Internal SDK Store and Comparator

TODO

## Comparator

- Comparator is a separate class injected in store. Usage: `this.store.getComparator().getTrackComparators().screenShare(trackA, trackB)`.
