export interface HMSPeerListIteratorOptions {
  role?: string;
  group?: string;
  peerIds?: string[];
  limit?: number;
}
