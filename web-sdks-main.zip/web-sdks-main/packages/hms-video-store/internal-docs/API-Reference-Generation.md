# Generating API Reference

- Run `yarn docs` in root directory - this should produce a **docs** directory in root.
- Copy the contents of `./docs/` to **'docs/api-references/javascript/v2'** of the [100ms Docs Repo](https://github.com/100mslive/100ms-docs).
