export interface ISignalParamsProvider<T> {
  toSignalParams(): T;
}
